import { useMemo } from "react";
import SafePlot from "../../../components/SafePlot";

function computeMSE(points, w, b) {
  if (!Array.isArray(points) || points.length === 0) return 0;
  let sum = 0;
  for (const point of points) {
    const error = w * point.x + b - point.y;
    sum += error * error;
  }
  return sum / points.length;
}

function estimateLinearSolution(points) {
  if (!Array.isArray(points) || points.length < 2) return { w: 0, b: 0 };
  const n = points.length;
  let sumX = 0;
  let sumY = 0;
  let sumXX = 0;
  let sumXY = 0;
  for (const point of points) {
    sumX += point.x;
    sumY += point.y;
    sumXX += point.x * point.x;
    sumXY += point.x * point.y;
  }
  const denom = n * sumXX - sumX * sumX;
  if (Math.abs(denom) < 1e-8) return { w: 0, b: sumY / n };
  const w = (n * sumXY - sumX * sumY) / denom;
  const b = (sumY - w * sumX) / n;
  return { w, b };
}

export default function LossLandscape3D({ enabled, points, model, trainLoss, testLoss }) {
  const plotData = useMemo(() => {
    if (!enabled || !Array.isArray(points) || points.length < 2) return null;

    const best = estimateLinearSolution(points);
    const currentW = Number.isFinite(model?.w) ? model.w : 0;
    const currentB = Number.isFinite(model?.b) ? model.b : 0;

    const centerW = Number.isFinite(best.w) ? best.w : currentW;
    const centerB = Number.isFinite(best.b) ? best.b : currentB;
    const wSpan = Math.max(1.6, Math.abs(centerW) * 1.4 + 1.2);
    const bSpan = Math.max(1.6, Math.abs(centerB) * 1.4 + 1.2);

    const steps = 34;
    const ws = [];
    const bs = [];
    const z = [];

    for (let i = 0; i < steps; i += 1) {
      const w = centerW - wSpan + (2 * wSpan * i) / (steps - 1);
      ws.push(w);
    }
    for (let j = 0; j < steps; j += 1) {
      const b = centerB - bSpan + (2 * bSpan * j) / (steps - 1);
      bs.push(b);
    }

    for (let i = 0; i < ws.length; i += 1) {
      const row = [];
      for (let j = 0; j < bs.length; j += 1) {
        const mse = computeMSE(points, ws[i], bs[j]);
        row.push(Math.min(mse, 25));
      }
      z.push(row);
    }

    const currentLossValue = Number.isFinite(trainLoss)
      ? trainLoss
      : computeMSE(points, currentW, currentB);
    const bestLoss = computeMSE(points, best.w, best.b);

    return {
      ws,
      bs,
      z,
      currentW,
      currentB,
      currentLossValue,
      bestW: best.w,
      bestB: best.b,
      bestLoss
    };
  }, [enabled, model?.b, model?.w, points, trainLoss]);

  if (!enabled) {
    return (
      <section className="reglab-panel reglab-landscape disabled">
        <div className="reglab-landscape-head">
          <strong>Loss Landscape 3D</strong>
        </div>
        <p>Available in Linear mode only.</p>
      </section>
    );
  }

  if (!plotData) {
    return (
      <section className="reglab-panel reglab-landscape disabled">
        <div className="reglab-landscape-head">
          <strong>Loss Landscape 3D</strong>
        </div>
        <p>Add at least two points to generate the surface.</p>
      </section>
    );
  }

  const traces = [
    {
      type: "surface",
      x: plotData.ws,
      y: plotData.bs,
      z: plotData.z,
      opacity: 0.85,
      showscale: false,
      colorscale: [
        [0, "#1e3a8a"],
        [0.55, "#0ea5e9"],
        [1, "#22d3ee"]
      ]
    },
    {
      type: "scatter3d",
      mode: "markers",
      x: [plotData.currentW],
      y: [plotData.currentB],
      z: [plotData.currentLossValue],
      marker: {
        size: 5,
        color: "#ef4444"
      },
      name: "Current"
    },
    {
      type: "scatter3d",
      mode: "markers",
      x: [plotData.bestW],
      y: [plotData.bestB],
      z: [plotData.bestLoss],
      marker: {
        size: 5,
        color: "#10b981"
      },
      name: "Best"
    }
  ];

  return (
    <section className="reglab-panel reglab-landscape">
      <div className="reglab-landscape-head">
        <strong>Loss Landscape 3D</strong>
        <span>
          Train {Number.isFinite(trainLoss) ? trainLoss.toFixed(4) : "--"}
          {Number.isFinite(testLoss) ? ` | Test ${testLoss.toFixed(4)}` : ""}
        </span>
      </div>
      <div className="reglab-landscape-plot">
        <SafePlot
          data={traces}
          layout={{
            paper_bgcolor: "rgba(0,0,0,0)",
            plot_bgcolor: "rgba(0,0,0,0)",
            margin: { l: 0, r: 0, t: 0, b: 0 },
            scene: {
              bgcolor: "rgba(7,17,34,0.65)",
              dragmode: "orbit",
              camera: {
                eye: { x: 1.5, y: 1.4, z: 1.2 }
              },
              xaxis: { title: "w", color: "#a7b9e2", gridcolor: "rgba(95,114,153,0.35)" },
              yaxis: { title: "b", color: "#a7b9e2", gridcolor: "rgba(95,114,153,0.35)" },
              zaxis: { title: "loss", color: "#a7b9e2", gridcolor: "rgba(95,114,153,0.35)" }
            },
            showlegend: true,
            legend: {
              orientation: "h",
              x: 0,
              y: 1,
              font: { color: "#dbe8ff", size: 10 },
              bgcolor: "rgba(0,0,0,0)"
            }
          }}
          config={{
            responsive: true,
            displaylogo: false,
            scrollZoom: true,
            modeBarButtonsToAdd: ["zoom3d", "pan3d", "resetCameraDefault3d"]
          }}
        />
      </div>
    </section>
  );
}
