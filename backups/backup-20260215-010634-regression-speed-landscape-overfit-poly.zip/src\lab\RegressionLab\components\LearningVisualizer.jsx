import { useEffect, useRef } from "react";

function drawChart(ctx, width, height, trainHistory, testHistory, mode) {
  const pad = { top: 24, right: 12, bottom: 30, left: 46 };
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "#0a1327";
  ctx.fillRect(0, 0, width, height);

  const chartW = width - pad.left - pad.right;
  const chartH = height - pad.top - pad.bottom;
  const minY = 0;
  const maxTrain = trainHistory.length ? Math.max(...trainHistory) : 0;
  const maxTest = testHistory.length ? Math.max(...testHistory) : 0;
  const maxRaw = Math.max(maxTrain, maxTest, 1e-6);
  const maxY = Math.max(mode === "linear" ? 0.2 : 0.6, maxRaw * 1.05);

  const toCanvas = (index, value) => {
    const x = pad.left + (index / Math.max(1, trainHistory.length - 1)) * chartW;
    const y = pad.top + chartH - ((value - minY) / Math.max(1e-8, maxY - minY)) * chartH;
    return { x, y };
  };

  ctx.strokeStyle = "rgba(90, 106, 145, 0.4)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i += 1) {
    const y = pad.top + (i / 4) * chartH;
    ctx.beginPath();
    ctx.moveTo(pad.left, y);
    ctx.lineTo(width - pad.right, y);
    ctx.stroke();
  }

  ctx.strokeStyle = "rgba(85, 101, 142, 0.34)";
  for (let i = 0; i <= 6; i += 1) {
    const x = pad.left + (i / 6) * chartW;
    ctx.beginPath();
    ctx.moveTo(x, pad.top);
    ctx.lineTo(x, height - pad.bottom);
    ctx.stroke();
  }

  if (trainHistory.length >= 2) {
    ctx.strokeStyle = "#22d3ee";
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    trainHistory.forEach((value, index) => {
      const point = toCanvas(index, value);
      if (index === 0) ctx.moveTo(point.x, point.y);
      else ctx.lineTo(point.x, point.y);
    });
    ctx.stroke();
  }

  if (testHistory.length >= 2) {
    ctx.strokeStyle = "#f97316";
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.beginPath();
    testHistory.forEach((value, index) => {
      const point = toCanvas(index, value);
      if (index === 0) ctx.moveTo(point.x, point.y);
      else ctx.lineTo(point.x, point.y);
    });
    ctx.stroke();
    ctx.setLineDash([]);
  }

  ctx.fillStyle = "#c5d4f7";
  ctx.font = "12px ui-monospace, SFMono-Regular, Menlo, monospace";
  ctx.fillText("Loss", 10, 16);
  ctx.fillText("0", pad.left - 12, height - pad.bottom + 16);
  ctx.fillText(maxY.toFixed(3), 8, pad.top + 4);
  ctx.fillText("Epoch", width - 56, height - 10);
}

function formatEquation(mode, linearVariant, model) {
  if (!model) return "";
  if (mode === "logistic") {
    const w1 = model.w1?.toFixed(3) ?? "0.000";
    const w2 = model.w2?.toFixed(3) ?? "0.000";
    const b = model.b?.toFixed(3) ?? "0.000";
    return `p = sigmoid(${w1}x + ${w2}y + ${b})`;
  }
  if (linearVariant === "polynomial" && Array.isArray(model.weights)) {
    return model.weights
      .map((coef, index) => {
        const value = Number(coef || 0).toFixed(3);
        if (index === 0) return `${value}`;
        if (index === 1) return `${value} * (x/5)`;
        return `${value} * (x/5)^${index}`;
      })
      .join(" + ");
  }
  const w = model.w?.toFixed(3) ?? "0.000";
  const b = model.b?.toFixed(3) ?? "0.000";
  return `y = ${w}x + ${b}`;
}

export default function LearningVisualizer({
  mode,
  linearVariant,
  model,
  history,
  testHistory = [],
  epoch,
  pointsCount,
  trainCount = pointsCount,
  testCount = 0,
  algorithm,
  lossFunction,
  isOverfitting = false
}) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(rect.width * dpr);
    canvas.height = Math.round(rect.height * dpr);
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawChart(ctx, rect.width, rect.height, history, testHistory, mode);
  }, [history, mode, testHistory]);

  const currentLoss = history.length ? history[history.length - 1] : null;
  const currentTestLoss = testHistory.length ? testHistory[testHistory.length - 1] : null;

  return (
    <section className="reglab-panel reglab-visualizer">
      <h4>Learning Visualizer</h4>
      <canvas ref={canvasRef} className="reglab-loss-canvas" />
      <div className="reglab-equation">
        <strong>Model</strong>
        <code>{formatEquation(mode, linearVariant, model)}</code>
        <div className="reglab-equation-meta">
          <span>{algorithm}</span>
          <span>{lossFunction}</span>
        </div>
      </div>
      <div className="reglab-visualizer-stats">
        <p>
          Epoch: <span className="reglab-mono">{epoch}</span>
        </p>
        <p>
          Points: <span className="reglab-mono">{pointsCount}</span> ({trainCount}/{testCount})
        </p>
        <p>
          Train: <span className="reglab-mono">{currentLoss !== null ? currentLoss.toFixed(5) : "--"}</span>
        </p>
        <p>
          Test: <span className="reglab-mono">{currentTestLoss !== null ? currentTestLoss.toFixed(5) : "--"}</span>
        </p>
        {isOverfitting && <p className="reglab-overfit-note">Overfitting detected: test loss is much higher than train loss.</p>}
      </div>
    </section>
  );
}
