import { useState } from "react";
import { Brain, Sigma, TrendingUp } from "lucide-react";
import ActivationLabRenderer from "../lab/ActivationLab/ActivationLabRenderer";
import RegressionLabRenderer from "../lab/RegressionLab/RegressionLabRenderer";
import NeuralPlayground from "./NeuralPlayground";
import "./ComputerScienceLab.css";

const CS_LABS = [
  {
    id: "neural",
    label: "Neural Playground",
    description: "Train neural networks and inspect decision boundaries",
    icon: Brain
  },
  {
    id: "activation",
    label: "Activation & Loss Lab",
    description: "Understand activations, losses, and optimization behavior",
    icon: Sigma
  },
  {
    id: "regression",
    label: "Regression Lab",
    description: "Interactive linear/logistic modeling with live updates",
    icon: TrendingUp
  }
];

export default function ComputerScienceLab() {
  const [activeLab, setActiveLab] = useState("neural");

  return (
    <div className="cslab-shell">
      <header className="cslab-header">
        <div className="cslab-title-wrap">
          <h2>Computer Science Lab</h2>
          <p>Interactive labs for neural networks, activation/loss analysis, and regression models.</p>
        </div>
        <div className="cslab-tabs">
          {CS_LABS.map((lab) => {
            const Icon = lab.icon;
            return (
              <button
                key={lab.id}
                type="button"
                className={`cslab-tab ${activeLab === lab.id ? "active" : ""}`}
                onClick={() => setActiveLab(lab.id)}
              >
                <span className="cslab-tab-icon">
                  <Icon size={16} />
                </span>
                <span className="cslab-tab-text">
                  <strong>{lab.label}</strong>
                  <small>{lab.description}</small>
                </span>
              </button>
            );
          })}
        </div>
      </header>

      <section className="cslab-stage">
        {activeLab === "neural" && <NeuralPlayground />}
        {activeLab === "activation" && <ActivationLabRenderer />}
        {activeLab === "regression" && <RegressionLabRenderer />}
      </section>
    </div>
  );
}
