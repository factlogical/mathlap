import { useEffect, useMemo, useRef, useState } from "react";
import InteractiveCanvas from "./components/InteractiveCanvas";
import LearningVisualizer from "./components/LearningVisualizer";
import ModelControls from "./components/ModelControls";
import { makeModel } from "./utils/regressionEngine";
import "./RegressionLab.css";

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function randomBetween(min, max) {
  return Math.random() * (max - min) + min;
}

function minPointsForMode(mode) {
  return mode === "logistic" ? 4 : 2;
}

function hasBothClasses(points) {
  let class0 = 0;
  let class1 = 0;
  for (const point of points) {
    if (point.label === 1) class1 += 1;
    else class0 += 1;
  }
  return class0 > 0 && class1 > 0;
}

function normalizePoint(point, mode) {
  const x = clamp(Number(point.x) || 0, -5, 5);
  const y = clamp(Number(point.y) || 0, -5, 5);
  if (mode === "logistic") {
    const label = point.label === 1 ? 1 : 0;
    return { x, y, label };
  }
  return { x, y };
}

function normalizePoints(points, mode) {
  return points.map((point) => normalizePoint(point, mode));
}

function buildLinearPreset(id = "linear_clear") {
  const points = [];
  const count = id === "linear_noisy" ? 34 : 26;
  const slope = id === "linear_outliers" ? 1.05 : 1.45;
  const intercept = id === "linear_outliers" ? -0.1 : 0.35;
  const noise = id === "linear_clear" ? 0.22 : 0.6;
  for (let i = 0; i < count; i += 1) {
    const x = randomBetween(-4.8, 4.8);
    const y = slope * x + intercept + randomBetween(-noise, noise);
    points.push({ x: clamp(x, -5, 5), y: clamp(y, -5, 5) });
  }
  if (id === "linear_outliers") {
    points.push({ x: -4.3, y: 4.7 });
    points.push({ x: 4.2, y: -4.6 });
  }
  return points;
}

function buildLogisticPreset(id = "logistic_circle") {
  const points = [];
  if (id === "logistic_linear") {
    for (let i = 0; i < 100; i += 1) {
      const x = randomBetween(-4.8, 4.8);
      const y = randomBetween(-4.8, 4.8);
      const margin = x * 0.75 + y * 0.55 + randomBetween(-1.1, 1.1);
      points.push({ x, y, label: margin > 0 ? 1 : 0 });
    }
    return points;
  }

  if (id === "logistic_xor") {
    for (let i = 0; i < 120; i += 1) {
      const x = randomBetween(-4.8, 4.8);
      const y = randomBetween(-4.8, 4.8);
      const label = (x > 0) !== (y > 0) ? 1 : 0;
      const noisyLabel = Math.random() < 0.08 ? (label ? 0 : 1) : label;
      points.push({ x, y, label: noisyLabel });
    }
    return points;
  }

  for (let i = 0; i < 120; i += 1) {
    const angle = randomBetween(0, Math.PI * 2);
    const radius = Math.sqrt(Math.random()) * 4.2;
    const x = radius * Math.cos(angle) + randomBetween(-0.22, 0.22);
    const y = radius * Math.sin(angle) + randomBetween(-0.22, 0.22);
    const label = radius < 2.2 ? 1 : 0;
    points.push({ x, y, label: Math.random() < 0.04 ? (label ? 0 : 1) : label });
  }
  return points;
}

function inferActionFromText(text) {
  const normalized = String(text || "")
    .toLowerCase()
    .replace(/[ًٌٍَُِّْـ]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه");

  if (/(linear|خطي|انحدار خطي)/.test(normalized)) {
    return { type: "change_model", params: { model: "linear" } };
  }
  if (/(logistic|لوجستي|تصنيف)/.test(normalized)) {
    return { type: "change_model", params: { model: "logistic" } };
  }
  if (/(clear|مسح|حذف النقاط)/.test(normalized)) {
    return { type: "clear_points", params: {} };
  }
  if (/(train|ابدا|شغل|ابدأ|start)/.test(normalized)) {
    return { type: "toggle_training", params: { run: true } };
  }
  if (/(pause|stop|ايقاف|توقف|وقف)/.test(normalized)) {
    return { type: "toggle_training", params: { run: false } };
  }
  if (/(circle|دائري|دائره)/.test(normalized)) {
    return { type: "add_preset", params: { preset: "logistic_circle" } };
  }
  if (/(xor|اكس اور)/.test(normalized)) {
    return { type: "add_preset", params: { preset: "logistic_xor" } };
  }
  const lrMatch = normalized.match(/(?:lr|learning rate|معدل التعلم)\s*[:=]?\s*([0-9]*\.?[0-9]+)/);
  if (lrMatch?.[1]) {
    const value = Number(lrMatch[1]);
    if (Number.isFinite(value)) return { type: "set_lr", params: { value } };
  }
  return null;
}

const INITIAL_CHAT = [
  {
    role: "assistant",
    text:
      "Regression Lab is ready. Try: 'switch to logistic', 'set lr 0.05', or 'apply circle preset'."
  }
];

export default function RegressionLabRenderer() {
  const [mode, setMode] = useState("linear");
  const [points, setPoints] = useState(() => buildLinearPreset("linear_clear"));
  const [learningRate, setLearningRate] = useState(0.02);
  const [stepsPerFrame, setStepsPerFrame] = useState(18);
  const [selectedClass, setSelectedClass] = useState(0);
  const [isTraining, setIsTraining] = useState(false);
  const [epoch, setEpoch] = useState(0);
  const [lossHistory, setLossHistory] = useState([]);
  const [renderTick, setRenderTick] = useState(0);
  const [chatVisible, setChatVisible] = useState(true);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [chatMessages, setChatMessages] = useState(INITIAL_CHAT);

  const modelRef = useRef(makeModel("linear"));
  const frameRef = useRef(0);
  const epochRef = useRef(0);
  const chatScrollRef = useRef(null);

  const classCounts = useMemo(() => {
    let class0 = 0;
    let class1 = 0;
    for (const point of points) {
      if (point.label === 1) class1 += 1;
      else class0 += 1;
    }
    return [class0, class1];
  }, [points]);

  const canTrain = useMemo(() => {
    if (points.length < minPointsForMode(mode)) return false;
    if (mode === "logistic") return hasBothClasses(points);
    return true;
  }, [mode, points]);

  useEffect(() => {
    if (!chatScrollRef.current) return;
    chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
  }, [chatMessages]);

  useEffect(() => {
    modelRef.current = makeModel(mode);
    modelRef.current.reset();
    setLossHistory([]);
    setEpoch(0);
    epochRef.current = 0;
    setRenderTick((value) => value + 1);
  }, [mode]);

  useEffect(() => {
    const model = modelRef.current;
    model.reset();
    setLossHistory([]);
    setEpoch(0);
    epochRef.current = 0;
    setRenderTick((value) => value + 1);
    if (canTrain) setIsTraining(true);
    else setIsTraining(false);
  }, [canTrain, points]);

  useEffect(() => {
    if (!isTraining || !canTrain) return undefined;
    cancelAnimationFrame(frameRef.current);

    const loop = () => {
      const model = modelRef.current;
      let hasLoss = false;
      for (let i = 0; i < stepsPerFrame; i += 1) {
        const loss = model.step(points, learningRate);
        hasLoss = hasLoss || Number.isFinite(loss);
      }

      if (!hasLoss) {
        setIsTraining(false);
        return;
      }

      epochRef.current += stepsPerFrame;
      setEpoch(epochRef.current);
      const latestHistory = model.history.slice(-360);
      setLossHistory(latestHistory);
      setRenderTick((value) => value + 1);

      const lastLoss = latestHistory[latestHistory.length - 1];
      const stopByLoss = mode === "linear" ? lastLoss < 0.0008 : lastLoss < 0.028;
      if (stopByLoss || epochRef.current >= 9000) {
        setIsTraining(false);
        return;
      }

      frameRef.current = requestAnimationFrame(loop);
    };

    frameRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frameRef.current);
  }, [canTrain, isTraining, learningRate, mode, points, stepsPerFrame]);

  const applyMode = (nextMode) => {
    const safeMode = nextMode === "logistic" ? "logistic" : "linear";
    setMode(safeMode);
    setPoints((prev) => normalizePoints(prev, safeMode));
    setLearningRate(safeMode === "linear" ? 0.02 : 0.08);
    setStepsPerFrame(safeMode === "linear" ? 18 : 24);
  };

  const applyPreset = (presetId) => {
    if (presetId.startsWith("linear")) {
      applyMode("linear");
      setPoints(buildLinearPreset(presetId));
      return;
    }
    applyMode("logistic");
    setPoints(buildLogisticPreset(presetId));
  };

  const handleAddPoint = (point) => {
    setPoints((prev) => [...prev, normalizePoint(point, mode)]);
  };

  const handleUpdatePoint = (index, nextPoint) => {
    setPoints((prev) => {
      const next = [...prev];
      if (!next[index]) return prev;
      next[index] = normalizePoint(nextPoint, mode);
      return next;
    });
  };

  const handleRemovePoint = (index) => {
    setPoints((prev) => prev.filter((_, pointIndex) => pointIndex !== index));
  };

  const handleResetModel = () => {
    modelRef.current.reset();
    setLossHistory([]);
    setEpoch(0);
    epochRef.current = 0;
    setRenderTick((value) => value + 1);
    if (canTrain) setIsTraining(true);
  };

  const handleClearPoints = () => {
    setPoints([]);
    setIsTraining(false);
  };

  const handleRandomData = () => {
    if (mode === "linear") {
      setPoints((prev) => [
        ...prev,
        ...buildLinearPreset("linear_noisy").slice(0, 16)
      ]);
      return;
    }
    setPoints((prev) => [
      ...prev,
      ...buildLogisticPreset("logistic_linear").slice(0, 24)
    ]);
  };

  const applyAssistantAction = (action) => {
    if (!action || typeof action !== "object") return false;
    const type = String(action.type || "").toLowerCase();
    const params = action.params && typeof action.params === "object" ? action.params : {};

    if (type === "change_model") {
      const target = String(params.model || "").toLowerCase();
      if (target === "linear" || target === "logistic") {
        applyMode(target);
        return true;
      }
      return false;
    }

    if (type === "set_lr") {
      const value = Number(params.value);
      if (!Number.isFinite(value)) return false;
      const max = mode === "linear" ? 0.08 : 0.3;
      setLearningRate(clamp(value, 0.001, max));
      return true;
    }

    if (type === "add_preset") {
      const preset = String(params.preset || "").toLowerCase();
      const valid = [
        "linear_clear",
        "linear_noisy",
        "linear_outliers",
        "logistic_circle",
        "logistic_xor",
        "logistic_linear"
      ];
      if (!valid.includes(preset)) return false;
      applyPreset(preset);
      return true;
    }

    if (type === "toggle_training") {
      const run =
        Object.prototype.hasOwnProperty.call(params, "run") ? Boolean(params.run) : !isTraining;
      if (run && canTrain) setIsTraining(true);
      if (!run) setIsTraining(false);
      return true;
    }

    if (type === "clear_points") {
      handleClearPoints();
      return true;
    }

    if (type === "set_class") {
      const label = Number(params.label);
      if (label === 0 || label === 1) {
        setSelectedClass(label);
        return true;
      }
    }

    return false;
  };

  const sendMessage = async (overrideText) => {
    const text = String(overrideText ?? chatInput).trim();
    if (!text || chatLoading) return;
    setChatMessages((prev) => [...prev, { role: "user", text }]);
    setChatInput("");
    setChatLoading(true);

    const fallbackAction = inferActionFromText(text);

    try {
      const response = await fetch("http://localhost:3002/api/interpret", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "regression_chat",
          message: text,
          context: {
            model: mode,
            points: points.length,
            loss: lossHistory.length ? lossHistory[lossHistory.length - 1] : null,
            epoch,
            learningRate
          }
        })
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      const applied = applyAssistantAction(data.action) || applyAssistantAction(fallbackAction);
      const base =
        typeof data.explanation === "string" && data.explanation.trim()
          ? data.explanation.trim()
          : applied
            ? "Command applied in Regression Lab."
            : "I could not parse the request.";
      setChatMessages((prev) => [...prev, { role: "assistant", text: base }]);
    } catch {
      const applied = applyAssistantAction(fallbackAction);
      setChatMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          text: applied
            ? "Applied locally. Start backend server on port 3002 for richer AI explanation."
            : "Server unavailable. Try short commands: 'set lr 0.03', 'switch logistic', 'clear points'."
        }
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  const currentLoss = lossHistory.length ? lossHistory[lossHistory.length - 1] : null;
  const trainingHint = useMemo(() => {
    if (mode === "logistic" && !hasBothClasses(points)) {
      return "Add points from both classes to train a boundary.";
    }
    if (!canTrain) return "Add more points to start optimization.";
    if (currentLoss === null) return "Model is ready. Add or move points to start training.";
    if (currentLoss > (mode === "linear" ? 1.2 : 0.7)) {
      return "Loss is still high. Try lower learning rate or cleaner data preset.";
    }
    return "Model is fitting the data. Drag points to test robustness.";
  }, [canTrain, currentLoss, mode, points]);

  return (
    <div className="reglab-shell">
      <header className="reglab-header">
        <div>
          <h3>Regression Lab</h3>
          <p>Click to add data points, then watch the model learn in real time.</p>
        </div>
        <div className="reglab-header-badges">
          <span className="reglab-badge">{mode === "linear" ? "Linear" : "Logistic"}</span>
          <span className="reglab-badge">Epoch {epoch}</span>
          <span className="reglab-badge">
            {currentLoss !== null ? `Loss ${currentLoss.toFixed(4)}` : "Loss --"}
          </span>
        </div>
      </header>

      <div className="reglab-main">
        <section className="reglab-panel reglab-stage">
          <InteractiveCanvas
            mode={mode}
            points={points}
            model={modelRef.current}
            selectedClass={selectedClass}
            renderTick={renderTick}
            onAddPoint={handleAddPoint}
            onUpdatePoint={handleUpdatePoint}
            onRemovePoint={handleRemovePoint}
          />
          <div className="reglab-hint">{trainingHint}</div>
        </section>

        <aside className="reglab-side">
          <ModelControls
            mode={mode}
            learningRate={learningRate}
            stepsPerFrame={stepsPerFrame}
            isTraining={isTraining}
            canTrain={canTrain}
            epoch={epoch}
            pointsCount={points.length}
            classCounts={classCounts}
            selectedClass={selectedClass}
            onModeChange={applyMode}
            onLearningRateChange={setLearningRate}
            onStepsChange={setStepsPerFrame}
            onToggleTraining={() => {
              if (!canTrain) {
                setIsTraining(false);
                return;
              }
              setIsTraining((value) => !value);
            }}
            onResetModel={handleResetModel}
            onClearPoints={handleClearPoints}
            onApplyPreset={applyPreset}
            onGenerateRandom={handleRandomData}
            onSelectedClassChange={setSelectedClass}
            onToggleChat={() => setChatVisible((value) => !value)}
          />

          <LearningVisualizer
            mode={mode}
            model={modelRef.current}
            history={lossHistory}
            epoch={epoch}
            pointsCount={points.length}
          />

          {chatVisible && (
            <section className="reglab-panel reglab-chat">
              <div className="reglab-chat-header">
                <strong>Regression AI Chat</strong>
                <span>Ready</span>
              </div>
              <div className="reglab-chat-log" ref={chatScrollRef}>
                {chatMessages.map((message, index) => (
                  <div key={`${message.role}-${index}`} className={`reglab-msg ${message.role}`}>
                    {message.text}
                  </div>
                ))}
                {chatLoading && <div className="reglab-msg assistant">Thinking...</div>}
              </div>
              <div className="reglab-chat-quick">
                <button type="button" onClick={() => sendMessage("switch logistic")}>
                  Logistic
                </button>
                <button type="button" onClick={() => sendMessage("set lr 0.03")}>
                  LR 0.03
                </button>
                <button type="button" onClick={() => sendMessage("apply circle preset")}>
                  Circle Preset
                </button>
              </div>
              <div className="reglab-chat-input">
                <input
                  value={chatInput}
                  onChange={(event) => setChatInput(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") sendMessage();
                  }}
                  placeholder="Ask: switch model, set lr, apply preset..."
                />
                <button type="button" onClick={() => sendMessage()}>
                  Send
                </button>
              </div>
            </section>
          )}
        </aside>
      </div>
    </div>
  );
}
