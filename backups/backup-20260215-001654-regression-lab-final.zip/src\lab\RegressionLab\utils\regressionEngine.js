export class LinearRegression {
  constructor() {
    this.w = 0;
    this.b = 0;
    this.history = [];
    this.paramHistory = [];
  }

  step(points, lr = 0.01) {
    if (!Array.isArray(points) || points.length < 2) return null;

    let dw = 0;
    let db = 0;
    const n = points.length;

    for (const point of points) {
      const error = this.predict(point.x) - point.y;
      dw += error * point.x;
      db += error;
    }

    this.w -= lr * (dw / n);
    this.b -= lr * (db / n);

    const mse = this.computeLoss(points);
    this.history.push(mse);
    this.paramHistory.push({ w: this.w, b: this.b });
    return mse;
  }

  predict(x) {
    return this.w * x + this.b;
  }

  computeLoss(points) {
    if (!Array.isArray(points) || points.length === 0) return Infinity;
    const n = points.length;
    let total = 0;
    for (const point of points) {
      const error = this.predict(point.x) - point.y;
      total += error * error;
    }
    return total / n;
  }

  reset() {
    this.w = 0;
    this.b = 0;
    this.history = [];
    this.paramHistory = [];
  }
}

export class LogisticRegression {
  constructor() {
    this.w1 = 0;
    this.w2 = 0;
    this.b = 0;
    this.history = [];
    this.paramHistory = [];
  }

  sigmoid(z) {
    const zSafe = Math.max(-40, Math.min(40, z));
    return 1 / (1 + Math.exp(-zSafe));
  }

  step(points, lr = 0.08) {
    if (!Array.isArray(points) || points.length < 2) return null;

    const n = points.length;
    let dw1 = 0;
    let dw2 = 0;
    let db = 0;

    for (const point of points) {
      const prediction = this.predict(point.x, point.y);
      const error = prediction - (point.label || 0);
      dw1 += error * point.x;
      dw2 += error * point.y;
      db += error;
    }

    this.w1 -= lr * (dw1 / n);
    this.w2 -= lr * (dw2 / n);
    this.b -= lr * (db / n);

    const loss = this.computeLoss(points);
    this.history.push(loss);
    this.paramHistory.push({ w1: this.w1, w2: this.w2, b: this.b });
    return loss;
  }

  predict(x, y) {
    return this.sigmoid(this.w1 * x + this.w2 * y + this.b);
  }

  decisionBoundaryY(x) {
    if (Math.abs(this.w2) < 1e-8) return 0;
    return (-this.w1 * x - this.b) / this.w2;
  }

  computeLoss(points) {
    if (!Array.isArray(points) || points.length === 0) return Infinity;
    const eps = 1e-8;
    const n = points.length;
    let total = 0;
    for (const point of points) {
      const prediction = Math.max(eps, Math.min(1 - eps, this.predict(point.x, point.y)));
      const label = point.label || 0;
      total += -(label * Math.log(prediction) + (1 - label) * Math.log(1 - prediction));
    }
    return total / n;
  }

  reset() {
    this.w1 = 0;
    this.w2 = 0;
    this.b = 0;
    this.history = [];
    this.paramHistory = [];
  }
}

export function knnPredict(points, queryX, queryY, k = 3) {
  if (!Array.isArray(points) || points.length < k) return null;
  const nearest = [...points]
    .filter((point) => typeof point.label === "number")
    .map((point) => ({
      ...point,
      distance: Math.hypot(point.x - queryX, point.y - queryY)
    }))
    .sort((a, b) => a.distance - b.distance)
    .slice(0, k);

  if (!nearest.length) return null;
  const votes = nearest.reduce((sum, point) => sum + (point.label ? 1 : 0), 0);
  return votes >= Math.ceil(k / 2) ? 1 : 0;
}

export function makeModel(kind = "linear") {
  return kind === "logistic" ? new LogisticRegression() : new LinearRegression();
}
