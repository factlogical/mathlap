import { useMemo, useRef, useState } from "react";
import ActivationChat from "./components/ActivationChat";
import FunctionExplorer from "./components/FunctionExplorer";
import LossFunctionViz from "./components/LossFunctionViz";
import NetworkBuilder from "./components/NetworkBuilder";
import { ACTIVATIONS, LOSSES } from "./utils/mathEngine";
import "./ActivationLab.css";

const TABS = [
  { id: "explorer", label: "مستعرض الدوال" },
  { id: "builder", label: "بناء الشبكة" },
  { id: "loss", label: "دوال الخسارة" }
];

const SIZE_MODES = [
  { id: "compact", label: "مضغوط" },
  { id: "normal", label: "عادي" },
  { id: "comfortable", label: "واسع" }
];

const HELP_CARDS = {
  intro: {
    id: "intro",
    icon: "💡",
    title: "كيف يعمل هذا المختبر؟",
    content:
      "حرّك معاملات كل وحدة (w و b و v) وراقب كيف يقترب منحنى المخرجات من منحنى الهدف."
  },
  high_mse: {
    id: "high_mse",
    icon: "⚠️",
    title: "الخطأ ما زال مرتفعًا",
    content: "جرّب تغيير نقطة التفعيل عبر b أو اختيار دالة تفعيل مختلفة لبعض الوحدات."
  },
  loss_hint: {
    id: "loss_hint",
    icon: "📉",
    title: "قراءة دوال الخسارة",
    content: "MAE خطية، MSE تربيعية، وCross-Entropy أشد حساسية للأخطاء الواثقة."
  }
};

const ACTIVATION_HELP_CARDS = {
  relu: {
    id: "tip_relu",
    icon: "🔵",
    title: "تلميح ReLU",
    content: "تُرجع الصفر للقيم السالبة وتبقي القيم الموجبة خطية."
  },
  sigmoid: {
    id: "tip_sigmoid",
    icon: "🟢",
    title: "تلميح Sigmoid",
    content: "تحصر الخرج بين 0 و1، مناسبة للاحتمالات لكنها قد تعاني من تلاشي التدرج."
  },
  tanh: {
    id: "tip_tanh",
    icon: "🟠",
    title: "تلميح Tanh",
    content: "تحصر الخرج بين -1 و1 وتتمركز حول الصفر."
  },
  leaky_relu: {
    id: "tip_leaky_relu",
    icon: "🟣",
    title: "تلميح Leaky ReLU",
    content: "تسمح بميل صغير في الجزء السالب لتقليل مشكلة الوحدات الميتة."
  },
  elu: {
    id: "tip_elu",
    icon: "🩷",
    title: "تلميح ELU",
    content: "سلوك أكثر نعومة في الجزء السالب وقد يساعد على الاستقرار."
  }
};

const INITIAL_MESSAGES = [
  {
    role: "assistant",
    content:
      "مرحبًا بك في مختبر دوال التفعيل والخسارة.\n\nجرّب أوامر مثل:\n- فعّل وضع المقارنة\n- قارن ReLU مع Tanh\n- تراجع\n- اجعل العرض واسعًا"
  }
];

const INITIAL_UI_STATE = {
  activeTab: "builder",
  selectedActivation: "relu",
  showDerivative: false,
  inputValue: 0,
  selectedLoss: "mse",
  showChat: true,
  compareMode: false,
  compareActivation: "sigmoid",
  sizeMode: "normal"
};

function toSnapshotKey(snapshot) {
  return JSON.stringify(snapshot);
}

function normalizeText(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[ًٌٍَُِّْـ]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .trim();
}

function HelpCard({ card, onDismiss }) {
  return (
    <div className="help-card">
      <span className="help-icon">{card.icon}</span>
      <div className="help-content">
        <strong>{card.title}</strong>
        <p>{card.content}</p>
      </div>
      <button type="button" className="help-dismiss" onClick={() => onDismiss(card.id)}>
        ×
      </button>
    </div>
  );
}

export default function ActivationLabRenderer() {
  const [activeTab, setActiveTab] = useState(INITIAL_UI_STATE.activeTab);
  const [selectedActivation, setSelectedActivation] = useState(INITIAL_UI_STATE.selectedActivation);
  const [showDerivative, setShowDerivative] = useState(INITIAL_UI_STATE.showDerivative);
  const [inputValue, setInputValue] = useState(INITIAL_UI_STATE.inputValue);
  const [selectedLoss, setSelectedLoss] = useState(INITIAL_UI_STATE.selectedLoss);
  const [showChat, setShowChat] = useState(INITIAL_UI_STATE.showChat);
  const [compareMode, setCompareMode] = useState(INITIAL_UI_STATE.compareMode);
  const [compareActivation, setCompareActivation] = useState(INITIAL_UI_STATE.compareActivation);
  const [sizeMode, setSizeMode] = useState(INITIAL_UI_STATE.sizeMode);

  const [messages, setMessages] = useState(INITIAL_MESSAGES);
  const [loading, setLoading] = useState(false);
  const [dismissedCards, setDismissedCards] = useState(() => new Set());
  const [builderMSE, setBuilderMSE] = useState(null);

  const [history, setHistory] = useState(() => [{ ...INITIAL_UI_STATE }]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const historyIndexRef = useRef(0);
  const suppressHistoryRef = useRef(false);

  const snapshot = (overrides = {}) => ({
    activeTab: overrides.activeTab ?? activeTab,
    selectedActivation: overrides.selectedActivation ?? selectedActivation,
    showDerivative: overrides.showDerivative ?? showDerivative,
    inputValue: overrides.inputValue ?? inputValue,
    selectedLoss: overrides.selectedLoss ?? selectedLoss,
    showChat: overrides.showChat ?? showChat,
    compareMode: overrides.compareMode ?? compareMode,
    compareActivation: overrides.compareActivation ?? compareActivation,
    sizeMode: overrides.sizeMode ?? sizeMode
  });

  const pushHistory = (overrides = {}) => {
    if (suppressHistoryRef.current) return;
    const next = snapshot(overrides);
    const nextKey = toSnapshotKey(next);

    setHistory((prev) => {
      const base = prev.slice(0, historyIndexRef.current + 1);
      const last = base[base.length - 1];
      if (last && toSnapshotKey(last) === nextKey) return prev;

      let merged = [...base, next];
      if (merged.length > 120) {
        merged = merged.slice(merged.length - 120);
      }

      const idx = merged.length - 1;
      historyIndexRef.current = idx;
      setHistoryIndex(idx);
      return merged;
    });
  };

  const applyHistorySnapshot = (entry) => {
    if (!entry) return;
    suppressHistoryRef.current = true;
    setActiveTab(entry.activeTab);
    setSelectedActivation(entry.selectedActivation);
    setShowDerivative(Boolean(entry.showDerivative));
    setInputValue(Number.isFinite(Number(entry.inputValue)) ? Number(entry.inputValue) : 0);
    setSelectedLoss(entry.selectedLoss);
    setShowChat(Boolean(entry.showChat));
    setCompareMode(Boolean(entry.compareMode));
    setCompareActivation(entry.compareActivation);
    setSizeMode(entry.sizeMode);
    requestAnimationFrame(() => {
      suppressHistoryRef.current = false;
    });
  };

  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < history.length - 1;

  const undo = () => {
    if (!canUndo) return;
    const nextIndex = historyIndexRef.current - 1;
    historyIndexRef.current = nextIndex;
    setHistoryIndex(nextIndex);
    applyHistorySnapshot(history[nextIndex]);
  };

  const redo = () => {
    if (!canRedo) return;
    const nextIndex = historyIndexRef.current + 1;
    historyIndexRef.current = nextIndex;
    setHistoryIndex(nextIndex);
    applyHistorySnapshot(history[nextIndex]);
  };

  const setTab = (tab, options = { record: true }) => {
    if (!TABS.some((item) => item.id === tab)) return;
    setActiveTab(tab);
    if (options.record !== false) pushHistory({ activeTab: tab });
  };

  const setActivation = (key, options = { record: true }) => {
    if (!ACTIVATIONS[key]) return;
    setSelectedActivation(key);
    if (options.record !== false) pushHistory({ selectedActivation: key });
  };

  const setDerivativeVisible = (show, options = { record: true }) => {
    setShowDerivative(Boolean(show));
    if (options.record !== false) pushHistory({ showDerivative: Boolean(show) });
  };

  const setInputZ = (value, options = { record: true }) => {
    const safe = Math.max(-5, Math.min(5, Number(value) || 0));
    setInputValue(safe);
    if (options.record !== false) pushHistory({ inputValue: safe });
  };

  const setLoss = (key, options = { record: true }) => {
    if (!LOSSES[key]) return;
    setSelectedLoss(key);
    if (options.record !== false) pushHistory({ selectedLoss: key });
  };

  const setChatVisible = (show, options = { record: true }) => {
    const safe = Boolean(show);
    setShowChat(safe);
    if (options.record !== false) pushHistory({ showChat: safe });
  };

  const setCompareModeValue = (show, options = { record: true }) => {
    const safe = Boolean(show);
    setCompareMode(safe);
    if (options.record !== false) pushHistory({ compareMode: safe });
  };

  const setCompareActivationValue = (key, options = { record: true }) => {
    if (!ACTIVATIONS[key]) return;
    setCompareActivation(key);
    if (options.record !== false) pushHistory({ compareActivation: key });
  };

  const setSizeModeValue = (mode, options = { record: true }) => {
    if (!SIZE_MODES.some((item) => item.id === mode)) return;
    setSizeMode(mode);
    if (options.record !== false) pushHistory({ sizeMode: mode });
  };

  const dismissCard = (id) => {
    setDismissedCards((prev) => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
  };

  const visibleCards = useMemo(() => {
    const cards = [];
    const has = (id) => !dismissedCards.has(id);
    if (activeTab === "builder" && has("intro")) cards.push(HELP_CARDS.intro);
    if (activeTab === "explorer") {
      const activationCard = ACTIVATION_HELP_CARDS[selectedActivation];
      if (activationCard && has(activationCard.id)) {
        cards.push(activationCard);
      }
    }
    if (activeTab === "loss" && has("loss_hint")) cards.push(HELP_CARDS.loss_hint);
    if (activeTab === "builder" && Number.isFinite(builderMSE) && builderMSE > 1.2 && has("high_mse")) {
      cards.push(HELP_CARDS.high_mse);
    }
    return cards;
  }, [activeTab, builderMSE, dismissedCards, selectedActivation]);

  const inferActionFromText = (text) => {
    const msg = normalizeText(text);
    if (!msg) return null;

    if (msg.includes("تراجع") || msg.includes("undo")) return { type: "undo", params: {} };
    if (msg.includes("اعاده") || msg.includes("اعادة") || msg.includes("redo")) {
      return { type: "redo", params: {} };
    }

    if (msg.includes("مقارنه") || msg.includes("compare mode")) {
      if (msg.includes("ايقاف") || msg.includes("تعطيل") || msg.includes("off")) {
        return { type: "toggle_compare_mode", params: { show: false } };
      }
      return { type: "toggle_compare_mode", params: { show: true } };
    }

    if (msg.includes("مضغوط") || msg.includes("compact")) {
      return { type: "set_size_mode", params: { mode: "compact" } };
    }
    if (msg.includes("واسع") || msg.includes("comfortable")) {
      return { type: "set_size_mode", params: { mode: "comfortable" } };
    }
    if (msg.includes("عادي") || msg.includes("normal")) {
      return { type: "set_size_mode", params: { mode: "normal" } };
    }

    if (msg.includes("اخف") && msg.includes("شات")) return { type: "set_chat_visibility", params: { show: false } };
    if ((msg.includes("اظهر") || msg.includes("افتح")) && msg.includes("شات")) {
      return { type: "set_chat_visibility", params: { show: true } };
    }

    if (msg.includes("loss") || msg.includes("خساره")) return { type: "set_tab", params: { tab: "loss" } };
    if (msg.includes("explorer") || msg.includes("مستعرض")) return { type: "set_tab", params: { tab: "explorer" } };
    if (msg.includes("builder") || msg.includes("شبكه")) return { type: "set_tab", params: { tab: "builder" } };

    if (msg.includes("relu")) return { type: "select_activation", params: { key: "relu" } };
    if (msg.includes("sigmoid")) return { type: "select_activation", params: { key: "sigmoid" } };
    if (msg.includes("tanh")) return { type: "select_activation", params: { key: "tanh" } };
    if (msg.includes("leaky")) return { type: "select_activation", params: { key: "leaky_relu" } };
    if (msg.includes("elu")) return { type: "select_activation", params: { key: "elu" } };

    if (msg.includes("mse")) return { type: "select_loss", params: { key: "mse" } };
    if (msg.includes("mae")) return { type: "select_loss", params: { key: "mae" } };
    if (msg.includes("cross")) return { type: "select_loss", params: { key: "cross_entropy" } };
    if (msg.includes("huber")) return { type: "select_loss", params: { key: "huber" } };

    if ((msg.includes("مشتقه") || msg.includes("derivative")) && (msg.includes("اخف") || msg.includes("off"))) {
      return { type: "toggle_derivative", params: { show: false } };
    }
    if (msg.includes("مشتقه") || msg.includes("derivative")) {
      return { type: "toggle_derivative", params: { show: true } };
    }

    return null;
  };

  const applyAssistantAction = (rawAction) => {
    if (!rawAction || typeof rawAction !== "object") return;
    const type = String(rawAction.type || "").toLowerCase();
    const params = rawAction.params && typeof rawAction.params === "object" ? rawAction.params : {};

    if (type === "undo") {
      undo();
      return;
    }
    if (type === "redo") {
      redo();
      return;
    }

    if (type === "set_tab" || type === "open_tab") {
      const tab = String(params.tab || "").toLowerCase();
      if (tab === "explorer" || tab === "builder" || tab === "loss") setTab(tab);
      return;
    }

    if (type === "select_activation") {
      const key = String(params.key || "").toLowerCase();
      if (ACTIVATIONS[key]) {
        setActivation(key, { record: false });
        setTab("explorer", { record: false });
        pushHistory({ selectedActivation: key, activeTab: "explorer" });
      }
      return;
    }

    if (type === "set_compare_activation") {
      const key = String(params.key || "").toLowerCase();
      if (ACTIVATIONS[key]) {
        setCompareActivationValue(key, { record: false });
        setCompareModeValue(true, { record: false });
        setTab("explorer", { record: false });
        pushHistory({ compareActivation: key, compareMode: true, activeTab: "explorer" });
      }
      return;
    }

    if (type === "toggle_compare_mode" || type === "toggle_compare") {
      const nextValue = Object.prototype.hasOwnProperty.call(params, "show")
        ? Boolean(params.show)
        : !compareMode;
      if (Object.prototype.hasOwnProperty.call(params, "show")) {
        setCompareModeValue(nextValue, { record: false });
      } else {
        setCompareModeValue(nextValue, { record: false });
      }
      setTab("explorer", { record: false });
      pushHistory({ compareMode: nextValue, activeTab: "explorer" });
      return;
    }

    if (type === "toggle_derivative") {
      const nextValue = Object.prototype.hasOwnProperty.call(params, "show")
        ? Boolean(params.show)
        : !showDerivative;
      if (Object.prototype.hasOwnProperty.call(params, "show")) {
        setDerivativeVisible(nextValue, { record: false });
      } else {
        setDerivativeVisible(nextValue, { record: false });
      }
      setTab("explorer", { record: false });
      pushHistory({ showDerivative: nextValue, activeTab: "explorer" });
      return;
    }

    if (type === "set_input") {
      const value = Number(params.value);
      if (Number.isFinite(value)) {
        const safe = Math.max(-5, Math.min(5, value));
        setInputZ(safe, { record: false });
        setTab("explorer", { record: false });
        pushHistory({ inputValue: safe, activeTab: "explorer" });
      }
      return;
    }

    if (type === "select_loss") {
      const key = String(params.key || "").toLowerCase();
      if (LOSSES[key]) {
        setLoss(key, { record: false });
        setTab("loss", { record: false });
        pushHistory({ selectedLoss: key, activeTab: "loss" });
      }
      return;
    }

    if (type === "set_size_mode") {
      const mode = String(params.mode || "").toLowerCase();
      if (mode === "compact" || mode === "normal" || mode === "comfortable") {
        setSizeModeValue(mode);
      }
      return;
    }

    if (type === "set_chat_visibility" || type === "toggle_chat") {
      if (Object.prototype.hasOwnProperty.call(params, "show")) {
        setChatVisible(Boolean(params.show));
      } else {
        setChatVisible(!showChat);
      }
    }
  };

  const sendMessage = async (text) => {
    const clean = String(text || "").trim();
    if (!clean || loading) return;

    setMessages((prev) => [...prev, { role: "user", content: clean }]);
    setLoading(true);

    try {
      const res = await fetch("http://localhost:3002/api/interpret", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: clean,
          mode: "activation_chat",
          context: {
            tab: activeTab,
            activation: selectedActivation,
            compareMode,
            compareActivation,
            showDerivative,
            inputValue,
            loss: selectedLoss,
            sizeMode,
            historyIndex,
            historyLength: history.length
          }
        })
      });

      if (!res.ok) throw new Error(`Server ${res.status}`);
      const data = await res.json();

      const fallbackAction = inferActionFromText(clean);
      applyAssistantAction(data.action || fallbackAction);

      const explanation =
        typeof data.explanation === "string" && data.explanation.trim()
          ? data.explanation
          : "لم أفهم الطلب بشكل كامل. جرّب صياغة أقصر.";
      const hint = typeof data.hint === "string" && data.hint.trim() ? `\n\n${data.hint}` : "";
      setMessages((prev) => [...prev, { role: "assistant", content: `${explanation}${hint}` }]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "تعذر الاتصال بالخادم. تأكد من تشغيل server على المنفذ 3002."
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const chatWidth = sizeMode === "compact" ? 300 : sizeMode === "comfortable" ? 360 : 335;

  return (
    <div className={`activation-lab size-${sizeMode}`}>
      <div className="al-header">
        <div className="al-header-info">
          <h2>مختبر دوال التفعيل والخسارة</h2>
          <p>تصور تفاعلي لدوال التفعيل، تجميع الوحدات، وسلوك دوال الخسارة أثناء التعلم.</p>
        </div>
        <div className="al-header-tools">
          <div className="al-tabs">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                type="button"
                className={`al-tab ${activeTab === tab.id ? "active" : ""}`}
                onClick={() => setTab(tab.id)}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div
        className="al-main"
        style={{ gridTemplateColumns: showChat ? `minmax(0, 1fr) ${chatWidth}px` : "minmax(0, 1fr)" }}
      >
        <div className={`al-content ${activeTab === "builder" ? "is-builder" : ""}`}>
          <div className="al-sticky-toolbar">
            <div className="al-toolbar-group">
              <button
                type="button"
                className={`al-tool-btn ${compareMode ? "active" : ""}`}
                onClick={() => setCompareModeValue(!compareMode)}
              >
                {compareMode ? "إيقاف المقارنة" : "وضع المقارنة"}
              </button>
              <select
                className="al-tool-select"
                value={compareActivation}
                disabled={!compareMode}
                onChange={(e) => setCompareActivationValue(e.target.value)}
              >
                {Object.entries(ACTIVATIONS).map(([key, item]) => (
                  <option key={key} value={key}>
                    {item.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="al-toolbar-group">
              <button type="button" className="al-tool-btn" disabled={!canUndo} onClick={undo}>
                تراجع
              </button>
              <button type="button" className="al-tool-btn" disabled={!canRedo} onClick={redo}>
                إعادة
              </button>
              <span className="al-history-meta">
                {historyIndex + 1}/{history.length}
              </span>
            </div>

            <div className="al-toolbar-group">
              {SIZE_MODES.map((mode) => (
                <button
                  key={mode.id}
                  type="button"
                  className={`al-tool-btn ${sizeMode === mode.id ? "active" : ""}`}
                  onClick={() => setSizeModeValue(mode.id)}
                >
                  {mode.label}
                </button>
              ))}
            </div>
          </div>

          <div className="help-stack">
            {visibleCards.map((card) => (
              <HelpCard key={card.id} card={card} onDismiss={dismissCard} />
            ))}
          </div>

          {activeTab === "explorer" && (
            <FunctionExplorer
              selected={selectedActivation}
              onSelect={setActivation}
              showDerivative={showDerivative}
              onToggleDerivative={setDerivativeVisible}
              inputValue={inputValue}
              onInputChange={setInputZ}
              compareMode={compareMode}
              compareActivation={compareActivation}
            />
          )}

          {activeTab === "builder" && <NetworkBuilder onMSEChange={setBuilderMSE} />}

          {activeTab === "loss" && <LossFunctionViz selectedLoss={selectedLoss} onSelectLoss={setLoss} />}
        </div>

        {showChat && (
          <div className="al-chat-column">
            <button type="button" className="al-chat-side-toggle" onClick={() => setChatVisible(false)}>
              إخفاء الشات
            </button>
            <ActivationChat
              messages={messages}
              onSend={sendMessage}
              isLoading={loading}
              onClose={() => setChatVisible(false)}
            />
          </div>
        )}
      </div>

      {!showChat && (
        <button type="button" className="al-chat-fab" onClick={() => setChatVisible(true)}>
          إظهار الشات
        </button>
      )}
    </div>
  );
}
