function sign(value) {
  if (value > 0) return 1;
  if (value < 0) return -1;
  return 0;
}

function normalizeX(value) {
  return Number(value) / 5;
}

function createPolynomialFeatures(x, degree) {
  const scaled = normalizeX(x);
  const out = [1];
  for (let d = 1; d <= degree; d += 1) {
    out.push(out[d - 1] * scaled);
  }
  return out;
}

function sampleBatch(points, algorithm = "batch", batchSize = 32) {
  if (!Array.isArray(points) || points.length === 0) return [];
  if (algorithm !== "mini_batch") return points;
  const size = Math.max(8, Math.min(points.length, batchSize));
  const batch = [];
  for (let i = 0; i < size; i += 1) {
    batch.push(points[Math.floor(Math.random() * points.length)]);
  }
  return batch;
}

function linearLossDerivative(error, loss = "mse", delta = 1) {
  if (loss === "mae") return sign(error);
  if (loss === "huber") {
    if (Math.abs(error) <= delta) return error;
    return delta * sign(error);
  }
  return 2 * error;
}

function logisticLossDerivative(prediction, label, loss = "bce") {
  const p = Math.max(1e-7, Math.min(1 - 1e-7, prediction));
  const y = label ? 1 : 0;
  const base = p - y;

  if (loss === "mae") {
    return sign(base) * p * (1 - p);
  }

  if (loss === "focal") {
    const gamma = 2;
    const pt = y === 1 ? p : 1 - p;
    const focus = Math.pow(1 - pt, gamma);
    return focus * base;
  }

  return base;
}

function computeLinearLoss(points, model, loss = "mse") {
  if (!Array.isArray(points) || points.length === 0) return Infinity;
  const n = points.length;
  let total = 0;
  for (const point of points) {
    const error = model.predict(point.x) - point.y;
    if (loss === "mae") total += Math.abs(error);
    else if (loss === "huber") {
      const absError = Math.abs(error);
      total += absError <= 1 ? 0.5 * absError * absError : absError - 0.5;
    } else total += error * error;
  }
  return total / n;
}

function computeLogisticLoss(points, model, loss = "bce") {
  if (!Array.isArray(points) || points.length === 0) return Infinity;
  const n = points.length;
  let total = 0;
  for (const point of points) {
    const y = point.label ? 1 : 0;
    const p = Math.max(1e-7, Math.min(1 - 1e-7, model.predict(point.x, point.y)));
    if (loss === "mae") {
      total += Math.abs(p - y);
    } else if (loss === "focal") {
      const pt = y === 1 ? p : 1 - p;
      total += -Math.pow(1 - pt, 2) * Math.log(pt);
    } else {
      total += -(y * Math.log(p) + (1 - y) * Math.log(1 - p));
    }
  }
  return total / n;
}

export class LinearRegression {
  constructor() {
    this.kind = "linear";
    this.w = 0;
    this.b = 0;
    this.vW = 0;
    this.vB = 0;
    this.lastGradient = 0;
    this.history = [];
    this.paramHistory = [];
  }

  step(points, options = {}) {
    if (!Array.isArray(points) || points.length < 2) return null;
    const {
      lr = 0.01,
      algorithm = "batch",
      loss = "mse",
      batchSize = 32,
      momentum = 0.86
    } = options;

    const active = sampleBatch(points, algorithm, batchSize);
    const n = active.length;
    if (!n) return null;

    let dW = 0;
    let dB = 0;
    for (const point of active) {
      const error = this.predict(point.x) - point.y;
      const dPred = linearLossDerivative(error, loss);
      dW += dPred * point.x;
      dB += dPred;
    }
    dW /= n;
    dB /= n;
    this.lastGradient = dW;

    if (algorithm === "momentum") {
      this.vW = momentum * this.vW + dW;
      this.vB = momentum * this.vB + dB;
      this.w -= lr * this.vW;
      this.b -= lr * this.vB;
    } else {
      this.w -= lr * dW;
      this.b -= lr * dB;
      this.vW = 0;
      this.vB = 0;
    }

    const lossValue = computeLinearLoss(points, this, loss);
    this.history.push(lossValue);
    this.paramHistory.push({ w: this.w, b: this.b });
    return lossValue;
  }

  predict(x) {
    return this.w * x + this.b;
  }

  computeLoss(points, loss = "mse") {
    return computeLinearLoss(points, this, loss);
  }

  reset() {
    this.w = 0;
    this.b = 0;
    this.vW = 0;
    this.vB = 0;
    this.lastGradient = 0;
    this.history = [];
    this.paramHistory = [];
  }
}

export class PolynomialRegression {
  constructor(degree = 3) {
    this.kind = "polynomial";
    this.degree = Math.max(1, Math.min(10, Math.round(degree)));
    this.weights = Array(this.degree + 1).fill(0);
    this.velocities = Array(this.degree + 1).fill(0);
    this.history = [];
    this.paramHistory = [];
    this.w = 0;
    this.b = 0;
  }

  setDegree(nextDegree) {
    const degree = Math.max(1, Math.min(10, Math.round(nextDegree)));
    if (degree === this.degree) return;
    const nextWeights = Array(degree + 1).fill(0);
    const nextVelocities = Array(degree + 1).fill(0);
    for (let i = 0; i < nextWeights.length; i += 1) {
      if (i < this.weights.length) nextWeights[i] = this.weights[i];
      if (i < this.velocities.length) nextVelocities[i] = this.velocities[i];
    }
    this.degree = degree;
    this.weights = nextWeights;
    this.velocities = nextVelocities;
    this.b = this.weights[0] || 0;
    this.w = (this.weights[1] || 0) / 5;
  }

  predict(x) {
    const features = createPolynomialFeatures(x, this.degree);
    let out = 0;
    for (let i = 0; i < this.weights.length; i += 1) {
      out += this.weights[i] * features[i];
    }
    return out;
  }

  step(points, options = {}) {
    if (!Array.isArray(points) || points.length < 2) return null;
    const {
      lr = 0.008,
      algorithm = "batch",
      loss = "mse",
      batchSize = 32,
      momentum = 0.88
    } = options;

    const active = sampleBatch(points, algorithm, batchSize);
    const n = active.length;
    if (!n) return null;

    const grads = Array(this.weights.length).fill(0);

    for (const point of active) {
      const features = createPolynomialFeatures(point.x, this.degree);
      const prediction = this.predict(point.x);
      const error = prediction - point.y;
      const dPred = linearLossDerivative(error, loss);
      for (let i = 0; i < grads.length; i += 1) {
        grads[i] += dPred * features[i];
      }
    }

    for (let i = 0; i < grads.length; i += 1) {
      grads[i] /= n;
      if (algorithm === "momentum") {
        this.velocities[i] = momentum * this.velocities[i] + grads[i];
        this.weights[i] -= lr * this.velocities[i];
      } else {
        this.weights[i] -= lr * grads[i];
        this.velocities[i] = 0;
      }
    }

    this.b = this.weights[0] || 0;
    this.w = (this.weights[1] || 0) / 5;

    const lossValue = computeLinearLoss(points, this, loss);
    this.history.push(lossValue);
    this.paramHistory.push({
      weights: [...this.weights],
      w: this.w,
      b: this.b
    });
    return lossValue;
  }

  computeLoss(points, loss = "mse") {
    return computeLinearLoss(points, this, loss);
  }

  reset() {
    this.weights = Array(this.degree + 1).fill(0);
    this.velocities = Array(this.degree + 1).fill(0);
    this.b = 0;
    this.w = 0;
    this.history = [];
    this.paramHistory = [];
  }
}

export class LogisticRegression {
  constructor() {
    this.kind = "logistic";
    this.w1 = 0;
    this.w2 = 0;
    this.b = 0;
    this.vW1 = 0;
    this.vW2 = 0;
    this.vB = 0;
    this.history = [];
    this.paramHistory = [];
  }

  sigmoid(z) {
    const clipped = Math.max(-40, Math.min(40, z));
    return 1 / (1 + Math.exp(-clipped));
  }

  step(points, options = {}) {
    if (!Array.isArray(points) || points.length < 2) return null;
    const {
      lr = 0.08,
      algorithm = "batch",
      loss = "bce",
      batchSize = 36,
      momentum = 0.88
    } = options;

    const active = sampleBatch(points, algorithm, batchSize);
    const n = active.length;
    if (!n) return null;

    let dW1 = 0;
    let dW2 = 0;
    let dB = 0;

    for (const point of active) {
      const y = point.label ? 1 : 0;
      const p = this.predict(point.x, point.y);
      const dZ = logisticLossDerivative(p, y, loss);
      dW1 += dZ * point.x;
      dW2 += dZ * point.y;
      dB += dZ;
    }

    dW1 /= n;
    dW2 /= n;
    dB /= n;

    if (algorithm === "momentum") {
      this.vW1 = momentum * this.vW1 + dW1;
      this.vW2 = momentum * this.vW2 + dW2;
      this.vB = momentum * this.vB + dB;
      this.w1 -= lr * this.vW1;
      this.w2 -= lr * this.vW2;
      this.b -= lr * this.vB;
    } else {
      this.w1 -= lr * dW1;
      this.w2 -= lr * dW2;
      this.b -= lr * dB;
      this.vW1 = 0;
      this.vW2 = 0;
      this.vB = 0;
    }

    const lossValue = computeLogisticLoss(points, this, loss);
    this.history.push(lossValue);
    this.paramHistory.push({ w1: this.w1, w2: this.w2, b: this.b });
    return lossValue;
  }

  predict(x, y) {
    return this.sigmoid(this.w1 * x + this.w2 * y + this.b);
  }

  decisionBoundaryY(x) {
    if (Math.abs(this.w2) < 1e-8) return 0;
    return (-this.w1 * x - this.b) / this.w2;
  }

  computeLoss(points, loss = "bce") {
    return computeLogisticLoss(points, this, loss);
  }

  reset() {
    this.w1 = 0;
    this.w2 = 0;
    this.b = 0;
    this.vW1 = 0;
    this.vW2 = 0;
    this.vB = 0;
    this.history = [];
    this.paramHistory = [];
  }
}

export function knnPredict(points, queryX, queryY, k = 3) {
  if (!Array.isArray(points) || points.length < k) return null;
  const nearest = [...points]
    .filter((point) => typeof point.label === "number")
    .map((point) => ({
      ...point,
      distance: Math.hypot(point.x - queryX, point.y - queryY)
    }))
    .sort((a, b) => a.distance - b.distance)
    .slice(0, k);

  if (!nearest.length) return null;
  const votes = nearest.reduce((sum, point) => sum + (point.label ? 1 : 0), 0);
  return votes >= Math.ceil(k / 2) ? 1 : 0;
}

export function makeModel(kind = "linear") {
  const safeKind = String(kind || "linear").toLowerCase();
  if (safeKind === "logistic") return new LogisticRegression();
  if (safeKind === "polynomial") return new PolynomialRegression();
  return new LinearRegression();
}
