import { useEffect, useRef } from "react";

function drawChart(ctx, width, height, history, mode) {
  const pad = { top: 24, right: 12, bottom: 30, left: 46 };
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "#0a1327";
  ctx.fillRect(0, 0, width, height);

  const chartW = width - pad.left - pad.right;
  const chartH = height - pad.top - pad.bottom;
  const minY = 0;
  const maxRaw = history.length ? Math.max(...history) : 1;
  const maxY = Math.max(mode === "linear" ? 0.2 : 0.6, maxRaw * 1.05);

  const toCanvas = (index, value) => {
    const x = pad.left + (index / Math.max(1, history.length - 1)) * chartW;
    const y = pad.top + chartH - ((value - minY) / Math.max(1e-8, maxY - minY)) * chartH;
    return { x, y };
  };

  ctx.strokeStyle = "rgba(90, 106, 145, 0.4)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i += 1) {
    const y = pad.top + (i / 4) * chartH;
    ctx.beginPath();
    ctx.moveTo(pad.left, y);
    ctx.lineTo(width - pad.right, y);
    ctx.stroke();
  }

  ctx.strokeStyle = "rgba(85, 101, 142, 0.34)";
  for (let i = 0; i <= 6; i += 1) {
    const x = pad.left + (i / 6) * chartW;
    ctx.beginPath();
    ctx.moveTo(x, pad.top);
    ctx.lineTo(x, height - pad.bottom);
    ctx.stroke();
  }

  if (history.length >= 2) {
    ctx.strokeStyle = "#22d3ee";
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    history.forEach((value, index) => {
      const point = toCanvas(index, value);
      if (index === 0) ctx.moveTo(point.x, point.y);
      else ctx.lineTo(point.x, point.y);
    });
    ctx.stroke();
  }

  ctx.fillStyle = "#c5d4f7";
  ctx.font = "12px ui-monospace, SFMono-Regular, Menlo, monospace";
  ctx.fillText("Loss", 10, 16);
  ctx.fillText("0", pad.left - 12, height - pad.bottom + 16);
  ctx.fillText(maxY.toFixed(3), 8, pad.top + 4);
  ctx.fillText("Epoch", width - 56, height - 10);
}

function formatEquation(mode, model) {
  if (!model) return "";
  if (mode === "logistic") {
    const w1 = model.w1?.toFixed(3) ?? "0.000";
    const w2 = model.w2?.toFixed(3) ?? "0.000";
    const b = model.b?.toFixed(3) ?? "0.000";
    return `p = σ(${w1}x + ${w2}y + ${b})`;
  }
  const w = model.w?.toFixed(3) ?? "0.000";
  const b = model.b?.toFixed(3) ?? "0.000";
  return `y = ${w}x + ${b}`;
}

export default function LearningVisualizer({
  mode,
  model,
  history,
  epoch,
  pointsCount,
  algorithm,
  lossFunction
}) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(rect.width * dpr);
    canvas.height = Math.round(rect.height * dpr);
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawChart(ctx, rect.width, rect.height, history, mode);
  }, [history, mode]);

  const currentLoss = history.length ? history[history.length - 1] : null;

  return (
    <section className="reglab-panel reglab-visualizer">
      <h4>Learning Visualizer</h4>
      <canvas ref={canvasRef} className="reglab-loss-canvas" />
      <div className="reglab-equation">
        <strong>Model</strong>
        <code>{formatEquation(mode, model)}</code>
        <div className="reglab-equation-meta">
          <span>{algorithm}</span>
          <span>{lossFunction}</span>
        </div>
      </div>
      <div className="reglab-visualizer-stats">
        <p>
          Epoch: <span className="reglab-mono">{epoch}</span>
        </p>
        <p>
          Points: <span className="reglab-mono">{pointsCount}</span>
        </p>
        <p>
          Loss:{" "}
          <span className="reglab-mono">
            {currentLoss !== null ? currentLoss.toFixed(5) : mode === "linear" ? "MSE --" : "CE --"}
          </span>
        </p>
      </div>
    </section>
  );
}
