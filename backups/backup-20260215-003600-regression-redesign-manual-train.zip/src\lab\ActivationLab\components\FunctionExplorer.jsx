import { useEffect, useMemo, useRef, useState } from "react";
import { ACTIVATIONS, generateCurveData } from "../utils/mathEngine";

function setupCanvas(canvas) {
  const rect = canvas.getBoundingClientRect();
  const w = Math.max(10, Math.floor(rect.width));
  const h = Math.max(10, Math.floor(rect.height));
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  return { ctx, w, h };
}

function strokeSmoothCurve(ctx, points) {
  if (!points.length) return;
  if (points.length === 1) {
    ctx.beginPath();
    ctx.arc(points[0].cx, points[0].cy, 1, 0, Math.PI * 2);
    ctx.fill();
    return;
  }

  ctx.beginPath();
  ctx.moveTo(points[0].cx, points[0].cy);
  for (let i = 1; i < points.length - 1; i += 1) {
    const midX = (points[i].cx + points[i + 1].cx) / 2;
    const midY = (points[i].cy + points[i + 1].cy) / 2;
    ctx.quadraticCurveTo(points[i].cx, points[i].cy, midX, midY);
  }
  const last = points[points.length - 1];
  ctx.lineTo(last.cx, last.cy);
  ctx.stroke();
}

function drawGlowLine(ctx, points, color, lineWidth = 2.2, dashed = false) {
  ctx.save();
  if (dashed) ctx.setLineDash([6, 4]);
  ctx.strokeStyle = `${color}55`;
  ctx.lineWidth = lineWidth * 2.8;
  ctx.filter = "blur(2.2px)";
  strokeSmoothCurve(ctx, points);
  ctx.restore();

  ctx.save();
  if (dashed) ctx.setLineDash([6, 4]);
  ctx.strokeStyle = color;
  ctx.lineWidth = lineWidth;
  ctx.filter = "none";
  strokeSmoothCurve(ctx, points);
  ctx.restore();
}

export default function FunctionExplorer({
  selected,
  onSelect,
  showDerivative,
  onToggleDerivative,
  inputValue,
  onInputChange
}) {
  const canvasRef = useRef(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const activation = useMemo(() => ACTIVATIONS[selected] || ACTIVATIONS.relu, [selected]);

  useEffect(() => {
    if (!isFullscreen) return undefined;
    const onKeyDown = (e) => {
      if (e.key === "Escape") setIsFullscreen(false);
    };
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [isFullscreen]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;
    let frame = 0;

    const draw = () => {
      if (!canvas.isConnected) return;
      const { ctx, w, h } = setupCanvas(canvas);

      const PAD = 52;
      const xMin = -5;
      const xMax = 5;
      const yMin = -2;
      const yMax = 2;

      const toCanvas = (x, y) => ({
        cx: PAD + ((x - xMin) / (xMax - xMin)) * (w - PAD * 2),
        cy: h - PAD - ((y - yMin) / (yMax - yMin)) * (h - PAD * 2)
      });

      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = "#0f172a";
      ctx.fillRect(0, 0, w, h);

      ctx.strokeStyle = "#1e293b";
      ctx.lineWidth = 1;
      for (let x = xMin; x <= xMax; x += 1) {
        const { cx } = toCanvas(x, 0);
        ctx.beginPath();
        ctx.moveTo(cx, PAD);
        ctx.lineTo(cx, h - PAD);
        ctx.stroke();
      }
      for (let y = yMin; y <= yMax; y += 0.5) {
        const { cy } = toCanvas(0, y);
        ctx.beginPath();
        ctx.moveTo(PAD, cy);
        ctx.lineTo(w - PAD, cy);
        ctx.stroke();
      }

      const { cx: ox, cy: oy } = toCanvas(0, 0);
      ctx.strokeStyle = "#475569";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(PAD, oy);
      ctx.lineTo(w - PAD, oy);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(ox, PAD);
      ctx.lineTo(ox, h - PAD);
      ctx.stroke();

      ctx.fillStyle = "#94a3b8";
      ctx.font = "11px monospace";
      ctx.textAlign = "center";
      for (let x = xMin; x <= xMax; x += 1) {
        if (x === 0) continue;
        const { cx } = toCanvas(x, 0);
        ctx.fillText(String(x), cx, oy + 18);
      }
      ctx.textAlign = "right";
      for (let y = yMin; y <= yMax; y += 0.5) {
        if (Math.abs(y) < 0.001) continue;
        const { cy } = toCanvas(0, y);
        ctx.fillText(y.toFixed(1), ox - 8, cy + 4);
      }

      const { xs, ys } = generateCurveData(activation.fn, xMin, xMax, 420);
      const fnPoints = xs.map((x, i) => toCanvas(x, Math.max(yMin, Math.min(yMax, ys[i]))));
      drawGlowLine(ctx, fnPoints, activation.color, 2.8);

      if (showDerivative) {
        const deriv = generateCurveData(activation.derivative, xMin, xMax, 420);
        const derivPoints = deriv.xs.map((x, i) =>
          toCanvas(x, Math.max(yMin, Math.min(yMax, deriv.ys[i])))
        );
        drawGlowLine(ctx, derivPoints, "#fbbf24", 1.8, true);
      }

      const z = Number(inputValue);
      const a = activation.fn(z);
      const { cx: px, cy: py } = toCanvas(z, Math.max(yMin, Math.min(yMax, a)));

      ctx.strokeStyle = "rgba(255,255,255,0.2)";
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(px, oy);
      ctx.lineTo(px, py);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(ox, py);
      ctx.lineTo(px, py);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = "#fbbf24";
      ctx.beginPath();
      ctx.arc(px, py, 6.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = "#fbbf24";
      ctx.font = "bold 13px monospace";
      ctx.textAlign = "left";
      ctx.fillText(`z=${z.toFixed(2)} -> a=${a.toFixed(4)}`, px + 10, py - 10);

      const legendItems = [{ name: activation.name, color: activation.color }];
      if (showDerivative) legendItems.push({ name: "f'(z)", color: "#fbbf24" });

      let lx = PAD + 8;
      const ly = PAD - 18;
      ctx.font = "11px sans-serif";
      legendItems.forEach((item) => {
        ctx.strokeStyle = item.color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(lx, ly);
        ctx.lineTo(lx + 20, ly);
        ctx.stroke();
        ctx.fillStyle = "#cbd5e1";
        ctx.fillText(item.name, lx + 25, ly + 3);
        lx += ctx.measureText(item.name).width + 52;
      });
    };

    const scheduleDraw = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(draw);
    };

    const resizeObserver = typeof ResizeObserver !== "undefined" ? new ResizeObserver(scheduleDraw) : null;
    scheduleDraw();
    window.addEventListener("resize", scheduleDraw);
    resizeObserver?.observe(canvas);
    if (canvas.parentElement) resizeObserver?.observe(canvas.parentElement);

    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("resize", scheduleDraw);
      resizeObserver?.disconnect();
    };
  }, [activation, inputValue, showDerivative]);

  return (
    <section className={`function-explorer ${isFullscreen ? "is-focus-mode" : ""}`}>
      <div className="fe-topbar">
        <button type="button" className="fe-fullscreen-btn" onClick={() => setIsFullscreen((prev) => !prev)}>
          {isFullscreen ? "خروج من الملء" : "ملء شاشة المستعرض"}
        </button>
      </div>

      <div className="fe-selector">
        {Object.entries(ACTIVATIONS).map(([key, act]) => (
          <button
            key={key}
            type="button"
            className={`fe-btn ${selected === key ? "active" : ""}`}
            style={{ "--color": act.color }}
            onClick={() => onSelect(key)}
          >
            <span className="btn-name">{act.name}</span>
            <code className="btn-formula">{act.formula}</code>
          </button>
        ))}
      </div>

      <div className="fe-body">
        <div className="fe-canvas-wrap">
          <canvas ref={canvasRef} className="fe-canvas" />
        </div>

        <div className="fe-controls">
          <div className="fe-info-card">
            <h4 style={{ color: activation.color }}>{activation.name}</h4>
            <code className="formula-display">{activation.formula}</code>
            <p>{activation.description}</p>
          </div>

          <div className="control-group">
            <label>
              المدخل z = <strong style={{ color: "#fbbf24" }}>{Number(inputValue).toFixed(2)}</strong>
            </label>
            <input
              className="styled-slider"
              type="range"
              min="-5"
              max="5"
              step="0.01"
              value={inputValue}
              onChange={(e) => onInputChange(parseFloat(e.target.value))}
            />
          </div>

          <div className="output-display">
            <div className="output-row">
              <span>المدخل z</span>
              <strong>{Number(inputValue).toFixed(4)}</strong>
            </div>
            <div className="output-row">
              <span>المخرج a</span>
              <strong style={{ color: activation.color }}>{activation.fn(Number(inputValue)).toFixed(4)}</strong>
            </div>
            {showDerivative && (
              <div className="output-row">
                <span>المشتقة f'(z)</span>
                <strong style={{ color: "#fbbf24" }}>{activation.derivative(Number(inputValue)).toFixed(4)}</strong>
              </div>
            )}
          </div>

          <label className="toggle-row">
            <input
              type="checkbox"
              checked={showDerivative}
              onChange={(e) => onToggleDerivative(e.target.checked)}
            />
            <span>عرض المشتقة (باللون الأصفر)</span>
          </label>
        </div>
      </div>
    </section>
  );
}
