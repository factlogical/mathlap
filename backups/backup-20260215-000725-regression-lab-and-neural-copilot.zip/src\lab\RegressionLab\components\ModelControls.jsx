const LINEAR_PRESETS = [
  { id: "linear_clear", label: "Linear Clear" },
  { id: "linear_noisy", label: "Linear Noisy" },
  { id: "linear_outliers", label: "With Outliers" }
];

const LOGISTIC_PRESETS = [
  { id: "logistic_circle", label: "Circle Split" },
  { id: "logistic_xor", label: "XOR Cloud" },
  { id: "logistic_linear", label: "Linear Split" }
];

export default function ModelControls({
  mode,
  learningRate,
  stepsPerFrame,
  isTraining,
  epoch,
  pointsCount,
  classCounts,
  selectedClass,
  onModeChange,
  onLearningRateChange,
  onStepsChange,
  onToggleTraining,
  onResetModel,
  onClearPoints,
  onApplyPreset,
  onGenerateRandom,
  onSelectedClassChange,
  onToggleChat
}) {
  const presets = mode === "linear" ? LINEAR_PRESETS : LOGISTIC_PRESETS;

  return (
    <section className="reglab-panel reglab-controls">
      <div className="reglab-controls-row">
        <label>
          Model
          <select value={mode} onChange={(event) => onModeChange(event.target.value)}>
            <option value="linear">Linear Regression</option>
            <option value="logistic">Logistic Regression</option>
          </select>
        </label>
      </div>

      <div className="reglab-presets">
        {presets.map((preset) => (
          <button key={preset.id} type="button" onClick={() => onApplyPreset(preset.id)}>
            {preset.label}
          </button>
        ))}
      </div>

      <div className="reglab-controls-row">
        <label>
          Learning Rate
          <span className="reglab-mono">{learningRate.toFixed(3)}</span>
        </label>
        <input
          type="range"
          min={mode === "linear" ? "0.001" : "0.005"}
          max={mode === "linear" ? "0.08" : "0.3"}
          step="0.001"
          value={learningRate}
          onChange={(event) => onLearningRateChange(parseFloat(event.target.value))}
        />
      </div>

      <div className="reglab-controls-row">
        <label>
          Steps / Frame
          <span className="reglab-mono">{stepsPerFrame}</span>
        </label>
        <input
          type="range"
          min="1"
          max="80"
          step="1"
          value={stepsPerFrame}
          onChange={(event) => onStepsChange(parseInt(event.target.value, 10))}
        />
      </div>

      {mode === "logistic" && (
        <div className="reglab-class-picker">
          <span>Left Click Class</span>
          <div>
            <button
              type="button"
              className={selectedClass === 0 ? "active class0" : "class0"}
              onClick={() => onSelectedClassChange(0)}
            >
              Class 0
            </button>
            <button
              type="button"
              className={selectedClass === 1 ? "active class1" : "class1"}
              onClick={() => onSelectedClassChange(1)}
            >
              Class 1
            </button>
          </div>
          <small>Right click always adds the opposite class.</small>
        </div>
      )}

      <div className="reglab-buttons">
        <button type="button" onClick={onToggleTraining}>
          {isTraining ? "Pause" : "Train"}
        </button>
        <button type="button" onClick={onResetModel}>
          Reset Model
        </button>
        <button type="button" onClick={onClearPoints}>
          Clear Points
        </button>
        <button type="button" onClick={onGenerateRandom}>
          Add Random Data
        </button>
      </div>

      <div className="reglab-stats">
        <p>
          Epoch <span className="reglab-mono">{epoch}</span>
        </p>
        <p>
          Points <span className="reglab-mono">{pointsCount}</span>
        </p>
        {mode === "logistic" && (
          <p>
            Class0 / Class1{" "}
            <span className="reglab-mono">
              {classCounts[0]} / {classCounts[1]}
            </span>
          </p>
        )}
      </div>

      <button type="button" className="reglab-chat-toggle" onClick={onToggleChat}>
        Toggle AI Chat
      </button>
    </section>
  );
}
