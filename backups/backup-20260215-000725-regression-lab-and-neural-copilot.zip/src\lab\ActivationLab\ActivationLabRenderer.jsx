import { useMemo, useState } from "react";
import ActivationChat from "./components/ActivationChat";
import FunctionExplorer from "./components/FunctionExplorer";
import LossFunctionViz from "./components/LossFunctionViz";
import NetworkBuilder from "./components/NetworkBuilder";
import { ACTIVATIONS, LOSSES } from "./utils/mathEngine";
import "./ActivationLab.css";

const TABS = [
  { id: "explorer", label: "مستعرض الدوال" },
  { id: "builder", label: "بناء الشبكة" },
  { id: "loss", label: "دوال الخسارة" }
];

const HELP_CARDS = {
  intro: {
    id: "intro",
    icon: "💡",
    title: "كيف يعمل هذا المختبر؟",
    content: "حرّك معاملات كل وحدة (w و b و v) وراقب كيف يقترب منحنى المخرجات من منحنى الهدف."
  },
  high_mse: {
    id: "high_mse",
    icon: "⚠️",
    title: "الخطأ ما زال مرتفعًا",
    content: "جرّب تعديل نقطة التفعيل عبر b أو تغيير دالة التفعيل لبعض الوحدات."
  },
  loss_hint: {
    id: "loss_hint",
    icon: "📉",
    title: "قراءة دوال الخسارة",
    content: "MAE خطية، MSE تربيعية، وCross-Entropy أشد حساسية للأخطاء الواثقة."
  }
};

const ACTIVATION_HELP_CARDS = {
  relu: {
    id: "tip_relu",
    icon: "🔵",
    title: "تلميح ReLU",
    content: "تُرجع الصفر للقيم السالبة وتبقي القيم الموجبة خطية."
  },
  sigmoid: {
    id: "tip_sigmoid",
    icon: "🟢",
    title: "تلميح Sigmoid",
    content: "تحصر الخرج بين 0 و1، مناسبة للاحتمالات لكنها قد تعاني من تلاشي التدرج."
  },
  tanh: {
    id: "tip_tanh",
    icon: "🟠",
    title: "تلميح Tanh",
    content: "تحصر الخرج بين -1 و1 وتتمركز حول الصفر."
  },
  leaky_relu: {
    id: "tip_leaky_relu",
    icon: "🟣",
    title: "تلميح Leaky ReLU",
    content: "تسمح بميل صغير في الجزء السالب لتقليل مشكلة الوحدات الميتة."
  },
  elu: {
    id: "tip_elu",
    icon: "🩷",
    title: "تلميح ELU",
    content: "سلوك أكثر نعومة في الجزء السالب وقد يساعد على استقرار التدريب."
  }
};

const INITIAL_MESSAGES = [
  {
    role: "assistant",
    content:
      "مرحبًا بك في مختبر دوال التفعيل والخسارة.\n\nيمكنني شرح المفاهيم وتطبيق الأوامر مباشرة داخل المختبر."
  }
];

function normalizeText(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[ًٌٍَُِّْـ]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .trim();
}

function HelpCard({ card, onDismiss }) {
  return (
    <div className="help-card">
      <span className="help-icon">{card.icon}</span>
      <div className="help-content">
        <strong>{card.title}</strong>
        <p>{card.content}</p>
      </div>
      <button type="button" className="help-dismiss" onClick={() => onDismiss(card.id)}>
        ×
      </button>
    </div>
  );
}

export default function ActivationLabRenderer() {
  const [activeTab, setActiveTab] = useState("builder");
  const [selectedActivation, setSelectedActivation] = useState("relu");
  const [showDerivative, setShowDerivative] = useState(false);
  const [inputValue, setInputValue] = useState(0);
  const [selectedLoss, setSelectedLoss] = useState("mse");
  const [showChat, setShowChat] = useState(true);
  const [messages, setMessages] = useState(INITIAL_MESSAGES);
  const [loading, setLoading] = useState(false);
  const [dismissedCards, setDismissedCards] = useState(() => new Set());
  const [builderMSE, setBuilderMSE] = useState(null);

  const dismissCard = (id) => {
    setDismissedCards((prev) => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
  };

  const visibleCards = useMemo(() => {
    const cards = [];
    const has = (id) => !dismissedCards.has(id);

    if (activeTab === "builder" && has("intro")) cards.push(HELP_CARDS.intro);
    if (activeTab === "explorer") {
      const activationCard = ACTIVATION_HELP_CARDS[selectedActivation];
      if (activationCard && has(activationCard.id)) cards.push(activationCard);
    }
    if (activeTab === "loss" && has("loss_hint")) cards.push(HELP_CARDS.loss_hint);
    if (activeTab === "builder" && Number.isFinite(builderMSE) && builderMSE > 1.2 && has("high_mse")) {
      cards.push(HELP_CARDS.high_mse);
    }
    return cards;
  }, [activeTab, builderMSE, dismissedCards, selectedActivation]);

  const inferActionFromText = (text) => {
    const msg = normalizeText(text);
    if (!msg) return null;

    if (msg.includes("اخف") && msg.includes("شات")) return { type: "set_chat_visibility", params: { show: false } };
    if ((msg.includes("اظهر") || msg.includes("افتح")) && msg.includes("شات")) {
      return { type: "set_chat_visibility", params: { show: true } };
    }

    if (msg.includes("مستعرض") || msg.includes("explorer")) return { type: "set_tab", params: { tab: "explorer" } };
    if (msg.includes("شبكه") || msg.includes("builder")) return { type: "set_tab", params: { tab: "builder" } };
    if (msg.includes("خساره") || msg.includes("loss")) return { type: "set_tab", params: { tab: "loss" } };

    if (msg.includes("relu")) return { type: "select_activation", params: { key: "relu" } };
    if (msg.includes("sigmoid")) return { type: "select_activation", params: { key: "sigmoid" } };
    if (msg.includes("tanh")) return { type: "select_activation", params: { key: "tanh" } };
    if (msg.includes("leaky")) return { type: "select_activation", params: { key: "leaky_relu" } };
    if (msg.includes("elu")) return { type: "select_activation", params: { key: "elu" } };

    if (msg.includes("mse")) return { type: "select_loss", params: { key: "mse" } };
    if (msg.includes("mae")) return { type: "select_loss", params: { key: "mae" } };
    if (msg.includes("cross")) return { type: "select_loss", params: { key: "cross_entropy" } };
    if (msg.includes("huber")) return { type: "select_loss", params: { key: "huber" } };

    const valueMatch = msg.match(/(?:z|input|مدخل|قيمة|value)\s*[:=]?\s*(-?\d+(?:\.\d+)?)/);
    if (valueMatch) {
      const value = Number(valueMatch[1]);
      if (Number.isFinite(value)) return { type: "set_input", params: { value } };
    }

    if ((msg.includes("مشتقه") || msg.includes("derivative")) && (msg.includes("اخف") || msg.includes("off"))) {
      return { type: "toggle_derivative", params: { show: false } };
    }
    if (msg.includes("مشتقه") || msg.includes("derivative")) {
      return { type: "toggle_derivative", params: { show: true } };
    }

    return null;
  };

  const applyAssistantAction = (rawAction) => {
    if (!rawAction || typeof rawAction !== "object") return false;
    const type = String(rawAction.type || "").toLowerCase();
    const params = rawAction.params && typeof rawAction.params === "object" ? rawAction.params : {};

    if (type === "set_tab" || type === "open_tab") {
      const tab = String(params.tab || "").toLowerCase();
      if (tab === "explorer" || tab === "builder" || tab === "loss") {
        setActiveTab(tab);
        return true;
      }
      return false;
    }

    if (type === "select_activation") {
      const key = String(params.key || "").toLowerCase();
      if (ACTIVATIONS[key]) {
        setSelectedActivation(key);
        setActiveTab("explorer");
        return true;
      }
      return false;
    }

    if (type === "toggle_derivative") {
      const next =
        Object.prototype.hasOwnProperty.call(params, "show") ? Boolean(params.show) : !showDerivative;
      setShowDerivative(next);
      setActiveTab("explorer");
      return true;
    }

    if (type === "set_input") {
      const value = Number(params.value);
      if (Number.isFinite(value)) {
        setInputValue(Math.max(-5, Math.min(5, value)));
        setActiveTab("explorer");
        return true;
      }
      return false;
    }

    if (type === "select_loss") {
      const key = String(params.key || "").toLowerCase();
      if (LOSSES[key]) {
        setSelectedLoss(key);
        setActiveTab("loss");
        return true;
      }
      return false;
    }

    if (type === "set_chat_visibility" || type === "toggle_chat") {
      const next = Object.prototype.hasOwnProperty.call(params, "show") ? Boolean(params.show) : !showChat;
      setShowChat(next);
      return true;
    }

    return false;
  };

  const sendMessage = async (text) => {
    const clean = String(text || "").trim();
    if (!clean || loading) return;

    setMessages((prev) => [...prev, { role: "user", content: clean }]);
    setLoading(true);

    try {
      const res = await fetch("http://localhost:3002/api/interpret", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: clean,
          mode: "activation_chat",
          context: {
            tab: activeTab,
            activation: selectedActivation,
            showDerivative,
            inputValue,
            loss: selectedLoss,
            builderMSE
          }
        })
      });

      if (!res.ok) throw new Error(`Server ${res.status}`);
      const data = await res.json();

      const fallbackAction = inferActionFromText(clean);
      const didApply = applyAssistantAction(data.action) || applyAssistantAction(fallbackAction);

      const explanation =
        typeof data.explanation === "string" && data.explanation.trim()
          ? data.explanation
          : didApply
            ? "تم تنفيذ الأمر المطلوب داخل المختبر."
            : "لم أفهم الطلب بالكامل. جرّب صياغة أقصر.";
      const hint = typeof data.hint === "string" && data.hint.trim() ? `\n\n${data.hint}` : "";
      setMessages((prev) => [...prev, { role: "assistant", content: `${explanation}${hint}` }]);
    } catch {
      const fallbackAction = inferActionFromText(clean);
      const didApply = applyAssistantAction(fallbackAction);
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: didApply
            ? "تم تنفيذ الأمر محليًا. وللحصول على شرح أذكى، تأكد من تشغيل server على المنفذ 3002."
            : "تعذر الاتصال بالخادم. تأكد من تشغيل server على المنفذ 3002."
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="activation-lab">
      <div className="al-header">
        <div className="al-header-info">
          <h2>مختبر دوال التفعيل والخسارة</h2>
          <p>تصور تفاعلي لدوال التفعيل، تجميع الوحدات، وسلوك دوال الخسارة أثناء التعلم.</p>
        </div>
        <div className="al-header-tools">
          <div className="al-tabs">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                type="button"
                className={`al-tab ${activeTab === tab.id ? "active" : ""}`}
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="al-main" style={{ gridTemplateColumns: showChat ? "minmax(0, 1fr) 335px" : "minmax(0, 1fr)" }}>
        <div className={`al-content ${activeTab === "builder" ? "is-builder" : ""}`}>
          <div className="help-stack">
            {visibleCards.map((card) => (
              <HelpCard key={card.id} card={card} onDismiss={dismissCard} />
            ))}
          </div>

          {activeTab === "explorer" && (
            <FunctionExplorer
              selected={selectedActivation}
              onSelect={setSelectedActivation}
              showDerivative={showDerivative}
              onToggleDerivative={setShowDerivative}
              inputValue={inputValue}
              onInputChange={setInputValue}
            />
          )}

          {activeTab === "builder" && <NetworkBuilder onMSEChange={setBuilderMSE} />}

          {activeTab === "loss" && (
            <LossFunctionViz selectedLoss={selectedLoss} onSelectLoss={setSelectedLoss} />
          )}
        </div>

        {showChat && (
          <div className="al-chat-column">
            <button type="button" className="al-chat-side-toggle" onClick={() => setShowChat(false)}>
              إخفاء الشات
            </button>
            <ActivationChat
              activeTab={activeTab}
              messages={messages}
              onSend={sendMessage}
              isLoading={loading}
              onClose={() => setShowChat(false)}
            />
          </div>
        )}
      </div>

      {!showChat && (
        <button type="button" className="al-chat-fab" onClick={() => setShowChat(true)}>
          إظهار الشات
        </button>
      )}
    </div>
  );
}
